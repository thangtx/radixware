var Rect = {
  // This is just a stub for a builtin native JavaScript object.
/**
 * See the 
 * bottom property definition in CSS2.
 * @type CSSPrimitiveValue
 */
bottom: undefined,
/**
 * See the 
 * left property definition in CSS2.
 * @type CSSPrimitiveValue
 */
left: undefined,
/**
 * See the 
 * right property definition in CSS2.
 * @type CSSPrimitiveValue
 */
right: undefined,
/**
 * See the 
 * top property definition in CSS2.
 * @type CSSPrimitiveValue
 */
top: undefined,
};

