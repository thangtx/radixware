var CSSUnknownRule = Object.extend(new CSSRule(), {
  // This is just a stub for a builtin native JavaScript object.
});

